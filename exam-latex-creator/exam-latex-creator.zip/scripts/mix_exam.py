# -*- coding: utf-8 -*-
"""
mix_exam.py — Ghép đề, trộn đề, phân tích và lọc trùng câu hỏi LaTeX.

Commands:
  assemble  — Ghép câu hỏi từ nhiều nguồn vào template đề thi
  shuffle   — Trộn đề tạo mã đề mới (xáo trộn câu hỏi + phương án)
  parse     — Phân tích và thống kê câu hỏi
  dedup     — Lọc câu hỏi trùng lặp

Usage:
  python mix_exam.py <command> [args]
"""
import os
import re
import sys
import json
import random
import hashlib
from difflib import SequenceMatcher

# Fix console encoding on Windows
if sys.platform.startswith('win'):
    import io
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
    except AttributeError:
        pass

# ==============================================================================
#                            CẤU TRÚC DỮ LIỆU CÂU HỎI
# ==============================================================================

class Question:
    def __init__(self, env_type, content, id6=None):
        self.env_type = env_type  # 'ex' or 'bt'
        self.content = content
        self.id6 = id6
        self.question_type = self._determine_type()

    def _determine_type(self):
        if self.env_type == 'bt':
            return 'BT'
        if '\\choiceTF' in self.content:
            return 'TF'
        if '\\shortans' in self.content:
            return 'SA'
        if '\\choice' in self.content:
            return 'EX'
        return 'BT'

# ==============================================================================
#                            PARSER & LOADER
# ==============================================================================

def find_next_brace_content(text, start_pos=0):
    try:
        open_brace_index = text.find('{', start_pos)
        if open_brace_index == -1:
            return None, -1, -1
        balance = 1
        i = open_brace_index + 1
        while i < len(text):
            char = text[i]
            if char == '\\':
                if i + 1 < len(text):
                    i += 2
                    continue
                else:
                    return None, -1, -1
            if char == '%':
                newline_index = text.find('\n', i)
                if newline_index == -1:
                    return None, -1, -1
                i = newline_index + 1
                continue
            if char == '{':
                balance += 1
            elif char == '}':
                balance -= 1
            if balance == 0:
                content = text[open_brace_index + 1 : i]
                return content, open_brace_index, i + 1
            i += 1
        return None, -1, -1
    except Exception:
        return None, -1, -1


def parse_questions_from_text(text):
    pattern = re.compile(r'\\begin\{(ex|bt)\}(.*?)\\end\{\1\}', re.DOTALL)
    questions = []
    for match in pattern.finditer(text):
        env_type = match.group(1)
        raw_content = match.group(2)
        id6 = None
        id_match = re.search(r'%\[\s*([^\]\s]+)\s*\]', raw_content)
        if id_match:
            id6 = id_match.group(1)
            content = raw_content[:id_match.start()] + raw_content[id_match.end():]
        else:
            content = raw_content
        content = content.strip()
        q = Question(env_type, content, id6)
        questions.append(q)
    return questions


def load_questions_from_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        return parse_questions_from_text(content)
    except Exception as e:
        print(f"[ERROR] Lỗi khi đọc file {filepath}: {e}")
        return []


def load_questions_from_paths(paths):
    questions = []
    for path in paths:
        if not os.path.exists(path):
            print(f"[WARN] Đường dẫn không tồn tại: {path}")
            continue
        if os.path.isdir(path):
            for root, dirs, files in os.walk(path):
                for file in files:
                    if file.endswith('.tex'):
                        filepath = os.path.join(root, file)
                        questions.extend(load_questions_from_file(filepath))
        else:
            questions.extend(load_questions_from_file(path))
    return questions

# ==============================================================================
#                            METADATA PARSER
# ==============================================================================

def parse_metadata_from_tex(tex_content):
    metadata = {}
    for field in ['monhoc', 'ngaykt', 'nh', 'thoigian', 'made']:
        match = re.search(r'\\gdef\\' + field + r'\{([^\}]*)\}', tex_content)
        if match:
            metadata[field] = match.group(1)
    match_sec = re.search(r'\\section\[([^\]]*?)(?:\s*-\s*Mã đề[^\]]*)\]', tex_content)
    if match_sec:
        metadata['ten_de'] = match_sec.group(1).strip()
    else:
        match_sec2 = re.search(r'\\section(?:\[[^\]]*\])?\{([^\}]+)\}', tex_content)
        if match_sec2:
            metadata['ten_de'] = match_sec2.group(1).strip()
    return metadata


def get_tenfile_and_made(output_path, default_made=None):
    filename = os.path.basename(output_path)
    if filename.endswith(".tex"):
        filename = filename[:-4]
    match = re.search(r'_MADE(\d+)$', filename, re.IGNORECASE)
    if match:
        made = match.group(1)
        ten_file = filename[:match.start()]
    else:
        match2 = re.search(r'MADE(\d+)$', filename, re.IGNORECASE)
        if match2:
            made = match2.group(1)
            ten_file = filename[:match2.start()]
        else:
            made = default_made if default_made else f"{random.randint(100, 999)}"
            ten_file = filename
    return ten_file, made

# ==============================================================================
#                            TEMPLATING / ASSEMBLY
# ==============================================================================

def format_question_list(questions, prefix):
    formatted = []
    for idx, q in enumerate(questions, 1):
        header = f"%%%%%============{prefix}_{idx}================%%%%%%"
        env = q.env_type
        if q.id6:
            begin_line = f"\\begin{{{env}}}%[{q.id6}]"
        else:
            begin_line = f"\\begin{{{env}}}"
        formatted.append(f"{header}\n{begin_line}\n{q.content}\n\\end{{{env}}}")
    return "\n\n".join(formatted)


def build_exam_string(questions, ten_file, made, metadata):
    ex_questions = [q for q in questions if q.question_type == 'EX']
    tf_questions = [q for q in questions if q.question_type == 'TF']
    sa_questions = [q for q in questions if q.question_type == 'SA']
    bt_questions = [q for q in questions if q.question_type == 'BT']

    ex_content = format_question_list(ex_questions, "EX")
    tf_content = format_question_list(tf_questions, "TF")
    sa_content = format_question_list(sa_questions, "SA")
    bt_content = format_question_list(bt_questions, "BT")

    lines = []
    lines.append("\\documentclass[FileMain.tex]{subfiles}")
    lines.append(f"\\gdef\\monhoc{{{metadata.get('monhoc', '<Tên môn học>')}}}")
    lines.append(f"\\gdef\\ngaykt{{{metadata.get('ngaykt', '<Ngày thi>')}}}")
    lines.append(f"\\gdef\\nh{{{metadata.get('nh', '2025 - 2026')}}}")
    lines.append(f"\\gdef\\thoigian{{{metadata.get('thoigian', '45')}}}")
    lines.append(f"\\gdef\\made{{{made}}}")
    lines.append("\\begin{document}")

    ten_ki_thi = metadata.get('ten_de', '<Tên kì thi>')
    lines.append(f"\\section[{ten_ki_thi} - Mã đề \\made]{{{ten_ki_thi}}}")
    lines.append("")

    if ex_questions:
        lines.append("%%%==============Phần trắc nghiệm nhiều lựa chọn==============%%%")
        lines.append(f"\\subsection{{Bài tập trắc nghiệm nhiều lựa chọn}}\\textit{{\\large Thí sinh trả lời từ câu 1 đến câu {len(ex_questions)}. Mỗi câu thí sinh chỉ chọn một phương án}}")
        lines.append(f"\\Opensolutionfile{{ansex}}[Ans/LGEX-{ten_file}_MADE{made}]")
        lines.append(f"\\Opensolutionfile{{ans}}[Ans/Ans-{ten_file}_MADE{made}]")
        lines.append(ex_content)
        lines.append("\\Closesolutionfile{ans}")
        lines.append("\\Closesolutionfile{ansex}")
        lines.append(f"%\\bangdapan{{Ans-{ten_file}_MADE{made}}}")

    if tf_questions:
        lines.append("%%%==============Phần trắc nghiệm đúng sai==============%%%")
        lines.append(f"\\subsection{{Trắc nghiệm đúng sai}}\\textit{{\\large Thí sinh trả lời từ câu 1 đến câu {len(tf_questions)}. Trong mỗi ý a), b), c), d) ở mỗi câu thí sinh chọn đúng hoặc sai}}")
        lines.append(f"\\Opensolutionfile{{ansex}}[Ans/LGTF-{ten_file}_MADE{made}]")
        lines.append(f"\\Opensolutionfile{{ansbook}}[Ansbook/AnsTF-{ten_file}_MADE{made}]")
        lines.append(f"\\Opensolutionfile{{ans}}[Ans/Tempt-{ten_file}_MADE{made}]")
        lines.append("\\setcounter{ex}{0}")
        lines.append(tf_content)
        lines.append("\\Closesolutionfile{ans}")
        lines.append("\\Closesolutionfile{ansbook}")
        lines.append("\\Closesolutionfile{ansex}")
        lines.append(f"%\\bangdapanTF{{AnsTF-{ten_file}_MADE{made}}}")

    if sa_questions:
        lines.append("%%%==============Phần bài tập trả lời ngắn==============%%%")
        lines.append(f"\\subsection{{Bài tập trả lời ngắn}}\\textit{{\\large Thí sinh trả lời từ câu 1 đến câu {len(sa_questions)}}}")
        lines.append(f"\\Opensolutionfile{{ansex}}[Ans/LGSA-{ten_file}_MADE{made}]")
        lines.append(f"\\Opensolutionfile{{ansexh}}[Ans/AnsSA-{ten_file}_MADE{made}]")
        lines.append("\\setcounter{ex}{0}")
        lines.append(sa_content)
        lines.append("\\Closesolutionfile{ansexh}")
        lines.append("\\Closesolutionfile{ansex}")
        lines.append(f"%\\bangdapanSA{{AnsSA-{ten_file}_MADE{made}}}")

    if bt_questions:
        lines.append("%%%==============Phần bài tập tự luận==============%%%")
        lines.append(f"\\subsection{{Bài tập tự luận}}\\textit{{\\large Thí sinh trả lời từ bài 1 đến bài {len(bt_questions)}}}")
        lines.append(f"\\Opensolutionfile{{ansbth}}[Ans/LGBT-{ten_file}_MADE{made}]")
        lines.append(f"\\Opensolutionfile{{ansbt}}[Ans/AnsBT-{ten_file}_MADE{made}]")
        lines.append(bt_content)
        lines.append("\\Closesolutionfile{ansbt}")
        lines.append("\\Closesolutionfile{ansbth}")

    lines.append("")
    lines.append("\\begin{center}")
    lines.append(" \\rule[4pt]{2cm}{1pt}\\,\\large\\bfseries Hết\\,\\rule[4pt]{2cm}{1pt}")
    lines.append("\\end{center}")
    lines.append("\\label{x}")
    lines.append("\\end{document}")

    return "\n".join(lines) + "\n"

# ==============================================================================
#                            SHUFFLER LOGIC
# ==============================================================================

def shuffle_loigiai_content(lg_content, shuffle_map):
    match = re.search(r'\\begin\{itemchoice\}\[([^\]]*)\](.*?)\\end\{itemchoice\}', lg_content, re.DOTALL)
    if match:
        labels_str = match.group(1)
        items_content = match.group(2)
        labels = [lbl.strip() for lbl in labels_str.split(',')]
        parts = re.split(r'\\itemch\b', items_content)

        if len(parts) >= 5 and len(labels) == 4:
            explanations = [part.strip() for part in parts[1:5]]
            inv_map = {new: old for old, new in shuffle_map.items()}
            new_explanations = [explanations[inv_map[i]] for i in range(4)]
            new_labels = []
            for i in range(4):
                old_idx = inv_map[i]
                old_lbl = labels[old_idx]
                new_lbl = old_lbl[0] + str(i + 1)
                new_labels.append(new_lbl)

            new_items_content = parts[0] + "\n" + "\n".join(f"\t\t\\itemch {exp}" for exp in new_explanations) + "\n\t"
            new_labels_str = ",".join(new_labels)
            new_itemchoice = f"\\begin{{itemchoice}}[{new_labels_str}]{new_items_content}\\end{{itemchoice}}"
            lg_content = lg_content[:match.start()] + new_itemchoice + lg_content[match.end():]

    return lg_content


def shuffle_question_options(block_content, seed):
    if '\\choiceTF' in block_content:
        cmd = '\\choiceTF'
    elif '\\choice' in block_content:
        cmd = '\\choice'
    else:
        return block_content

    idx = block_content.find(cmd)
    if idx == -1:
        return block_content

    start = idx + len(cmd)
    opt1, s1, e1 = find_next_brace_content(block_content, start)
    if opt1 is None: return block_content
    opt2, s2, e2 = find_next_brace_content(block_content, e1)
    if opt2 is None: return block_content
    opt3, s3, e3 = find_next_brace_content(block_content, e2)
    if opt3 is None: return block_content
    opt4, s4, e4 = find_next_brace_content(block_content, e3)
    if opt4 is None: return block_content

    options = [opt1, opt2, opt3, opt4]
    indices = [0, 1, 2, 3]

    rng = random.Random(seed)
    rng.shuffle(indices)

    shuffle_map = {old: new for new, old in enumerate(indices)}
    new_options = [options[i] for i in indices]
    new_choice_part = cmd + "\n" + "\n".join(f"\t{{{opt}}}" for opt in new_options)

    lg_idx = block_content.find('\\loigiai')
    if lg_idx != -1:
        lg_content, lg_s, lg_e = find_next_brace_content(block_content, lg_idx)
        if lg_content:
            shuffled_lg = shuffle_loigiai_content(lg_content, shuffle_map)
            block_content = (
                block_content[:s1] +
                new_choice_part +
                block_content[e4:lg_s] +
                "{" + shuffled_lg + "}" +
                block_content[lg_e:]
            )
            return block_content

    block_content = block_content[:s1] + new_choice_part + block_content[e4:]
    return block_content


def shuffle_questions(questions, seed):
    ex_qs = [q for q in questions if q.question_type == 'EX']
    tf_qs = [q for q in questions if q.question_type == 'TF']
    sa_qs = [q for q in questions if q.question_type == 'SA']
    bt_qs = [q for q in questions if q.question_type == 'BT']

    rng = random.Random(seed)
    rng.shuffle(ex_qs)
    rng.shuffle(tf_qs)
    rng.shuffle(sa_qs)
    rng.shuffle(bt_qs)

    for i, q in enumerate(ex_qs):
        q.content = shuffle_question_options(q.content, seed + i)
    for i, q in enumerate(tf_qs):
        q.content = shuffle_question_options(q.content, seed + 1000 + i)

    return ex_qs + tf_qs + sa_qs + bt_qs

# ==============================================================================
#                            DEDUPLICATION
# ==============================================================================

def normalize_text_for_comparison(text):
    text = re.sub(r'%.*?\n', '\n', text)
    text = re.sub(r'\s+', ' ', text)
    text = re.sub(r'%\[.*?\]', '', text)
    return text.strip().lower()


def calculate_similarity(text1, text2):
    norm1 = normalize_text_for_comparison(text1)
    norm2 = normalize_text_for_comparison(text2)
    return SequenceMatcher(None, norm1, norm2).ratio()


def get_text_hash(text):
    normalized = normalize_text_for_comparison(text)
    return hashlib.md5(normalized.encode('utf-8')).hexdigest()


def remove_duplicates(questions, threshold=0.85):
    unique_questions = []
    removed_count = 0
    seen_hashes = set()

    for q in questions:
        h = get_text_hash(q.content)
        if h in seen_hashes:
            removed_count += 1
            continue
        is_duplicate = False
        for uq in unique_questions:
            if q.question_type == uq.question_type:
                similarity = calculate_similarity(q.content, uq.content)
                if similarity >= threshold:
                    is_duplicate = True
                    removed_count += 1
                    break
        if not is_duplicate:
            unique_questions.append(q)
            seen_hashes.add(h)

    return unique_questions, removed_count

# ==============================================================================
#                            COMMAND HANDLERS
# ==============================================================================

def cmd_parse(args):
    import argparse
    parser = argparse.ArgumentParser(description="Phân tích câu hỏi LaTeX và hiển thị thống kê.")
    parser.add_argument("path", help="Đường dẫn file hoặc thư mục")
    parsed = parser.parse_args(args)

    questions = load_questions_from_paths([parsed.path])
    if not questions:
        print(f"Không tìm thấy câu hỏi nào tại: {parsed.path}")
        return

    stats = {
        'total': len(questions),
        'EX': sum(1 for q in questions if q.question_type == 'EX'),
        'TF': sum(1 for q in questions if q.question_type == 'TF'),
        'SA': sum(1 for q in questions if q.question_type == 'SA'),
        'BT': sum(1 for q in questions if q.question_type == 'BT'),
    }

    print("=== THỐNG KÊ NGÂN HÀNG CÂU HỎI ===")
    print(f"Tổng số câu: {stats['total']}")
    print(f"Trắc nghiệm nhiều lựa chọn (EX): {stats['EX']}")
    print(f"Trắc nghiệm đúng sai (TF): {stats['TF']}")
    print(f"Trả lời ngắn (SA): {stats['SA']}")
    print(f"Tự luận (BT): {stats['BT']}")


def cmd_dedup(args):
    import argparse
    parser = argparse.ArgumentParser(description="Lọc câu hỏi trùng lặp.")
    parser.add_argument("input_path", help="Đường dẫn file/thư mục nguồn")
    parser.add_argument("output_file", help="Đường dẫn file lưu kết quả")
    parser.add_argument("--threshold", type=float, default=0.85, help="Ngưỡng tương đồng (0.0-1.0)")
    parsed = parser.parse_args(args)

    questions = load_questions_from_paths([parsed.input_path])
    if not questions:
        print("Không tìm thấy câu hỏi nào.")
        return

    initial_count = len(questions)
    print(f"Nạp {initial_count} câu hỏi. Đang lọc trùng...")

    unique_qs, removed = remove_duplicates(questions, parsed.threshold)

    print(f"Đã loại bỏ {removed} câu trùng. Còn lại: {len(unique_qs)} câu.")

    os.makedirs(os.path.dirname(os.path.abspath(parsed.output_file)), exist_ok=True)
    with open(parsed.output_file, 'w', encoding='utf-8') as f:
        for idx, q in enumerate(unique_qs, 1):
            f.write(f"%%%============={q.question_type}_{idx}=============%%%\n")
            if q.id6:
                f.write(f"\\begin{{{q.env_type}}}%[{q.id6}]\n")
            else:
                f.write(f"\\begin{{{q.env_type}}}\n")
            f.write(q.content)
            f.write(f"\n\\end{{{q.env_type}}}\n\n")

    print(f"Lưu kết quả: {parsed.output_file}")


def cmd_shuffle(args):
    import argparse
    parser = argparse.ArgumentParser(description="Trộn câu hỏi và phương án để sinh mã đề mới.")
    parser.add_argument("source", help="File LaTeX đề thi gốc")
    parser.add_argument("--seed", type=int, default=42, help="Seed xáo trộn")
    parser.add_argument("--made2", type=str, default=None, help="Mã đề mới (3 chữ số)")
    parser.add_argument("--out-name", type=str, default=None, help="Đường dẫn file output")
    parsed = parser.parse_args(args)

    if not os.path.exists(parsed.source):
        print(f"Lỗi: File nguồn không tồn tại: {parsed.source}")
        sys.exit(1)

    with open(parsed.source, 'r', encoding='utf-8') as f:
        src_content = f.read()

    questions = parse_questions_from_text(src_content)
    metadata = parse_metadata_from_tex(src_content)

    made2 = parsed.made2
    if made2 is None:
        old_made = metadata.get('made', '101')
        try:
            made2 = f"{int(old_made) + 1:03d}"
        except Exception:
            made2 = f"{random.randint(100, 999)}"

    shuffled_qs = shuffle_questions(questions, parsed.seed)

    if parsed.out_name:
        out_path = parsed.out_name
        if not out_path.endswith('.tex'):
            out_path += '.tex'
    else:
        source_dir = os.path.dirname(os.path.abspath(parsed.source))
        source_base = os.path.basename(parsed.source)
        if source_base.endswith('.tex'):
            source_base = source_base[:-4]
        match = re.search(r'(_?)MADE(\d+)', source_base, re.IGNORECASE)
        if match:
            new_base = source_base[:match.start()] + match.group(1) + "MADE" + made2
        else:
            new_base = source_base + "_MADE" + made2
        out_path = os.path.join(source_dir, new_base + ".tex")

    ten_file, _ = get_tenfile_and_made(out_path, made2)
    assembled_content = build_exam_string(shuffled_qs, ten_file, made2, metadata)

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(assembled_content)

    print(f"Trộn đề thành công -> {out_path}")


def cmd_assemble(args):
    import argparse
    parser = argparse.ArgumentParser(description="Ghép câu hỏi LaTeX vào mẫu đề thi.")
    parser.add_argument("--input", nargs="+", help="Các file/thư mục chứa câu hỏi")
    parser.add_argument("--output", help="Đường dẫn file đề thi đầu ra")
    parser.add_argument("--monhoc", default=None, help="Tên môn học")
    parser.add_argument("--ngaykt", default=None, help="Ngày thi")
    parser.add_argument("--nh", default="2025 - 2026", help="Năm học")
    parser.add_argument("--thoigian", default="45", help="Thời gian (phút)")
    parser.add_argument("--made", default=None, help="Mã đề thi")
    parser.add_argument("--ten-de", default="Kiểm tra", help="Tên kì thi")
    parser.add_argument("--config", help="File JSON cấu hình")
    parsed = parser.parse_args(args)

    cfg = {}
    if parsed.config:
        if os.path.exists(parsed.config):
            with open(parsed.config, 'r', encoding='utf-8') as f:
                cfg = json.load(f)
        else:
            print(f"Lỗi: Không tìm thấy config: {parsed.config}")
            sys.exit(1)

    inputs = parsed.input if parsed.input else cfg.get("input", [])
    if not inputs and "parts" in cfg:
        inputs = [p for p in cfg["parts"].values() if p]
    if isinstance(inputs, str):
        inputs = [inputs]

    output = parsed.output if parsed.output else cfg.get("output", "assembled_exam.tex")
    monhoc = parsed.monhoc if parsed.monhoc else cfg.get("monhoc", "<Tên môn học>")
    ngaykt = parsed.ngaykt if parsed.ngaykt else cfg.get("ngaykt", "<Ngày thi>")
    nh = parsed.nh if parsed.nh else cfg.get("nh", "2025 - 2026")
    thoigian = parsed.thoigian if parsed.thoigian else cfg.get("thoigian", "45")
    made = parsed.made if parsed.made else cfg.get("made", None)
    ten_de = parsed.ten_de if parsed.ten_de else cfg.get("ten_de", "Kiểm tra")

    if not inputs:
        print("Lỗi: Không chỉ định file đầu vào (dùng --input hoặc --config).")
        sys.exit(1)

    questions = load_questions_from_paths(inputs)
    if not questions:
        print("Lỗi: Không phân tích được câu hỏi nào.")
        sys.exit(1)

    ten_file, computed_made = get_tenfile_and_made(output, made)
    metadata = {
        'monhoc': monhoc, 'ngaykt': ngaykt, 'nh': nh,
        'thoigian': thoigian, 'ten_de': ten_de
    }

    assembled_content = build_exam_string(questions, ten_file, computed_made, metadata)

    os.makedirs(os.path.dirname(os.path.abspath(output)), exist_ok=True)
    with open(output, 'w', encoding='utf-8') as f:
        f.write(assembled_content)

    print(f"Ghép đề thành công -> {output}")

# ==============================================================================
#                            ENTRY POINT
# ==============================================================================

COMMANDS = {
    "assemble": cmd_assemble,
    "shuffle": cmd_shuffle,
    "parse": cmd_parse,
    "dedup": cmd_dedup,
}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python mix_exam.py <command> [args]")
        print("Commands:", ", ".join(COMMANDS.keys()))
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd in COMMANDS:
        COMMANDS[cmd](sys.argv[2:])
    else:
        print(f"Lỗi: Lệnh không hợp lệ: {cmd}")
        print("Commands:", ", ".join(COMMANDS.keys()))
        sys.exit(1)
